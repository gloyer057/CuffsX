/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.datagen.v1.provider;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

import com.google.common.base.Preconditions;
import com.google.common.collect.Sets;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import org.jetbrains.annotations.Nullable;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.resource.conditions.v1.ResourceCondition;
import net.fabricmc.fabric.impl.datagen.FabricDataGenHelper;
import net.minecraft.advancement.Advancement;
import net.minecraft.class_8779;
import net.minecraft.class_8790;
import net.minecraft.data.DataOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.DataWriter;
import net.minecraft.data.server.recipe.CraftingRecipeJsonBuilder;
import net.minecraft.data.server.recipe.RecipeProvider;
import net.minecraft.data.server.recipe.ShapedRecipeJsonBuilder;
import net.minecraft.data.server.recipe.ShapelessRecipeJsonBuilder;
import net.minecraft.recipe.Recipe;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryOps;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.Identifier;

/**
 * Extend this class and implement {@link FabricRecipeProvider#method_62766}.
 *
 * <p>Register an instance of the class with {@link FabricDataGenerator.Pack#addProvider} in a {@link net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint}.
 */
public abstract class FabricRecipeProvider extends RecipeProvider.class_10114 {
	protected final FabricDataOutput output;
	private final CompletableFuture<RegistryWrapper.WrapperLookup> registriesFuture;

	public FabricRecipeProvider(FabricDataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> registriesFuture) {
		super(output, registriesFuture);
		this.output = output;
		this.registriesFuture = registriesFuture;
	}

	/**
	 * Implement this method and then use the range of methods in {@link RecipeProvider} or from one of the recipe json factories such as {@link ShapedRecipeJsonBuilder} or {@link ShapelessRecipeJsonBuilder}.
	 */
	@Override
	protected abstract RecipeProvider method_62766(RegistryWrapper.WrapperLookup registryLookup, class_8790 exporter);

	/**
	 * Return a new exporter that applies the specified conditions to any recipe json provider it receives.
	 */
	protected class_8790 withConditions(class_8790 exporter, ResourceCondition... conditions) {
		Preconditions.checkArgument(conditions.length > 0, "Must add at least one condition.");
		return new class_8790() {
			@Override
			public void method_53819(RegistryKey<Recipe<?>> key, Recipe<?> recipe, @Nullable class_8779 advancementEntry) {
				FabricDataGenHelper.addConditions(recipe, conditions);
				exporter.method_53819(key, recipe, advancementEntry);
			}

			@Override
			public Advancement.Builder method_53818() {
				return exporter.method_53818();
			}

			@Override
			public void method_62738() {
			}
		};
	}

	@Override
	public CompletableFuture<?> run(DataWriter writer) {
		return registriesFuture.thenCompose((wrapperLookup -> {
			Set<Identifier> generatedRecipes = Sets.newHashSet();
			List<CompletableFuture<?>> list = new ArrayList<>();
			RecipeProvider recipeGenerator = method_62766(wrapperLookup, new class_8790() {
				@Override
				public void method_53819(RegistryKey<Recipe<?>> recipeKey, Recipe<?> recipe, @Nullable class_8779 advancement) {
					Identifier identifier = getRecipeIdentifier(recipeKey.getValue());

					if (!generatedRecipes.add(identifier)) {
						throw new IllegalStateException("Duplicate recipe " + identifier);
					}

					RegistryOps<JsonElement> registryOps = wrapperLookup.method_57093(JsonOps.INSTANCE);
					JsonObject recipeJson = class_1860.field_47319.encodeStart(registryOps, recipe).getOrThrow(IllegalStateException::new).getAsJsonObject();
					ResourceCondition[] conditions = FabricDataGenHelper.consumeConditions(recipe);
					FabricDataGenHelper.addConditions(recipeJson, conditions);

					final DataOutput.PathResolver recipesPathResolver = output.method_60917(class_7924.field_52178);
					final DataOutput.PathResolver advancementsPathResolver = output.method_60917(class_7924.field_52177);

					list.add(DataProvider.writeToPath(writer, recipeJson, recipesPathResolver.resolveJson(identifier)));

					if (advancement != null) {
						JsonObject advancementJson = class_161.field_47179.encodeStart(registryOps, advancement.comp_1920()).getOrThrow(IllegalStateException::new).getAsJsonObject();
						FabricDataGenHelper.addConditions(advancementJson, conditions);
						list.add(DataProvider.writeToPath(writer, advancementJson, advancementsPathResolver.resolveJson(getRecipeIdentifier(advancement.comp_1919()))));
					}
				}

				@Override
				public Advancement.Builder method_53818() {
					//noinspection removal
					return Advancement.Builder.createUntelemetered().parent(CraftingRecipeJsonBuilder.ROOT);
				}

				@Override
				public void method_62738() {
				}
			});
			recipeGenerator.generate();
			return CompletableFuture.allOf(list.toArray(CompletableFuture[]::new));
		}));
	}

	/**
	 * Override this method to change the recipe identifier. The default implementation normalizes the namespace to the mod ID.
	 */
	protected Identifier getRecipeIdentifier(Identifier identifier) {
		return Identifier.method_60655(output.getModId(), identifier.getPath());
	}
}
