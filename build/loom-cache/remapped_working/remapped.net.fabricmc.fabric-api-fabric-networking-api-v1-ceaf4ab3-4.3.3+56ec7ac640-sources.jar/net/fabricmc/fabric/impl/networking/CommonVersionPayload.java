/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.networking;

import class_9154;
import net.minecraft.class_8710;
import net.minecraft.class_9139;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;

public record CommonVersionPayload(int[] versions) implements class_8710 {
	public static final class_9139<PacketByteBuf, CommonVersionPayload> CODEC = class_8710.method_56484(CommonVersionPayload::write, CommonVersionPayload::new);
	public static final class_8710.class_9154<CommonVersionPayload> ID = new class_9154<>(Identifier.method_60654("c:version"));

	private CommonVersionPayload(PacketByteBuf buf) {
		this(buf.readIntArray());
	}

	public void write(PacketByteBuf buf) {
		buf.writeIntArray(versions);
	}

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
