/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.recipe.ingredient.builtin;

import java.util.List;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredient;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredientSerializer;
import net.minecraft.class_10302;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

public class CustomDataIngredient implements CustomIngredient {
	public static final CustomIngredientSerializer<CustomDataIngredient> SERIALIZER = new Serializer();
	private final Ingredient base;
	private final NbtCompound nbt;

	public CustomDataIngredient(Ingredient base, NbtCompound nbt) {
		if (nbt == null || nbt.isEmpty()) throw new IllegalArgumentException("NBT cannot be null; use components ingredient for strict matching");

		this.base = base;
		this.nbt = nbt;
	}

	@Override
	public boolean test(ItemStack stack) {
		if (!base.test(stack)) return false;

		class_9279 nbt = stack.method_57824(class_9334.field_49628);

		return nbt != null && nbt.method_57460(this.nbt);
	}

	@Override
	public List<RegistryEntry<Item>> getMatchingItems() {
		return base.getMatchingStacks();
	}

	@Override
	public class_10302 toDisplay() {
		return new class_10302.class_10304(
				base.getMatchingStacks().stream().map(this::createEntryDisplay).toList()
		);
	}

	private class_10302 createEntryDisplay(RegistryEntry<Item> entry) {
		ItemStack stack = entry.value().getDefaultStack();
		stack.method_57368(class_9334.field_49628, class_9279.field_49302, existingNbt -> class_9279.method_57456(existingNbt.method_57461().method_10543(nbt)));
		return new class_10302.class_10307(stack);
	}

	@Override
	public boolean requiresTesting() {
		return true;
	}

	@Override
	public CustomIngredientSerializer<?> getSerializer() {
		return SERIALIZER;
	}

	private Ingredient getBase() {
		return base;
	}

	private NbtCompound getNbt() {
		return nbt;
	}

	private static class Serializer implements CustomIngredientSerializer<CustomDataIngredient> {
		private static final Identifier ID = Identifier.method_60655("fabric", "custom_data");

		private static final MapCodec<CustomDataIngredient> CODEC = RecordCodecBuilder.mapCodec(instance ->
				instance.group(
						class_1856.field_46095.fieldOf("base").forGetter(CustomDataIngredient::getBase),
						class_2522.field_51469.fieldOf("nbt").forGetter(CustomDataIngredient::getNbt)
				).apply(instance, CustomDataIngredient::new)
		);

		private static final class_9139<class_9129, CustomDataIngredient> PACKET_CODEC = class_9139.method_56435(
				class_1856.field_48355, CustomDataIngredient::getBase,
				class_9135.field_48556, CustomDataIngredient::getNbt,
				CustomDataIngredient::new
		);

		@Override
		public Identifier getIdentifier() {
			return ID;
		}

		@Override
		public MapCodec<CustomDataIngredient> getCodec() {
			return CODEC;
		}

		@Override
		public class_9139<class_9129, CustomDataIngredient> getPacketCodec() {
			return PACKET_CODEC;
		}
	}
}
