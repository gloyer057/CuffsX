package org.gloyer057.cuffsx.command;

import com.mojang.brigadier.CommandDispatcher;
import me.lucko.fabric.api.permissions.v0.Permissions;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import org.gloyer057.cuffsx.cuff.CuffLog;
import org.gloyer057.cuffsx.cuff.CuffManager;
import org.gloyer057.cuffsx.cuff.CuffRecord;
import org.gloyer057.cuffsx.cuff.CuffState;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.List;

import static net.minecraft.class_2170.method_9247;

public class CuffsxCommand {

    private static final DateTimeFormatter TIME_FMT =
            DateTimeFormatter.ofPattern("HH:mm:ss").withZone(ZoneId.systemDefault());

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            method_9247("cuffsx")
                .then(method_9247("reload")
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        if (!Permissions.check(source, "cuffsx.reload", 4)) {
                            source.method_9213(class_2561.method_43470("У вас нет прав для выполнения этой команды."));
                            return 0;
                        }
                        CuffManager.setEnabled(true);
                        source.method_9226(() -> class_2561.method_43470("Конфигурация cuffsx перезагружена."), false);
                        return 1;
                    }))
                .then(method_9247("enable")
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        if (!Permissions.check(source, "cuffsx.enable", 4)) {
                            source.method_9213(class_2561.method_43470("У вас нет прав для выполнения этой команды."));
                            return 0;
                        }
                        CuffManager.setEnabled(true);
                        source.method_9226(() -> class_2561.method_43470("Наручники включены."), false);
                        return 1;
                    }))
                .then(method_9247("disable")
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        if (!Permissions.check(source, "cuffsx.disable", 4)) {
                            source.method_9213(class_2561.method_43470("У вас нет прав для выполнения этой команды."));
                            return 0;
                        }
                        CuffManager.setEnabled(false);
                        source.method_9226(() -> class_2561.method_43470("Наручники отключены."), false);
                        return 1;
                    }))
                .then(method_9247("list")
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        if (!Permissions.check(source, "cuffsx.list", 4)) {
                            source.method_9213(class_2561.method_43470("У вас нет прав для выполнения этой команды."));
                            return 0;
                        }
                        CuffState state = CuffState.getOrCreate(source.method_9211());
                        Collection<CuffRecord> all = state.getAllRecords();
                        if (all.isEmpty()) {
                            source.method_9226(() -> class_2561.method_43470("Нет игроков в наручниках."), false);
                        } else {
                            long now = System.currentTimeMillis();
                            for (CuffRecord r : all) {
                                long elapsed = (now - r.timestamp()) / 1000;
                                String msg = String.format("%s | %s | надел(а): %s | %d сек. назад",
                                        r.targetName(), r.cuffType(), r.applierName(), elapsed);
                                source.method_9226(() -> class_2561.method_43470(msg), false);
                            }
                        }
                        return 1;
                    }))
                .then(method_9247("log")
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        if (!Permissions.check(source, "cuffsx.log", 4)) {
                            source.method_9213(class_2561.method_43470("У вас нет прав для выполнения этой команды."));
                            return 0;
                        }
                        List<CuffLog.LogEntry> recent = CuffLog.getRecent();
                        if (recent.isEmpty()) {
                            source.method_9226(
                                () -> class_2561.method_43470("Нет взаимодействий за последние 2 часа."), false);
                        } else {
                            for (CuffLog.LogEntry e : recent) {
                                String action = e.action() == CuffLog.Action.APPLY ? "APPLY" : "REMOVE";
                                String time = TIME_FMT.format(Instant.ofEpochMilli(e.timestamp()));
                                String msg = String.format("%s | %s → %s | %s | (%.1f, %.1f, %.1f) | %s",
                                        action, e.applierName(), e.targetName(), e.cuffType(),
                                        e.coords().field_1352, e.coords().field_1351, e.coords().field_1350, time);
                                source.method_9226(() -> class_2561.method_43470(msg), false);
                            }
                        }
                        return 1;
                    }))
        );
    }
}
