package org.gloyer057.cuffsx.mixin;

import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_3222;
import org.gloyer057.cuffsx.cuff.CuffManager;
import org.gloyer057.cuffsx.cuff.CuffType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1723.class)
public abstract class PlayerScreenHandlerMixin {

    @Inject(method = "onSlotClick", at = @At("HEAD"), cancellable = true)
    private void cuffsx_onSlotClick(int slotIndex, int button, class_1713 actionType, class_1657 player, CallbackInfo ci) {
        if (player instanceof class_3222 sp && CuffManager.isCuffed(sp, CuffType.HANDS)) {
            ci.cancel();
        }
    }
}
