package org.gloyer057.cuffsx.mixin;

import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import org.gloyer057.cuffsx.cuff.CuffManager;
import org.gloyer057.cuffsx.cuff.CuffType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3222.class)
public abstract class ServerPlayerEntityMixin {

    @Inject(method = "jump", at = @At("HEAD"), cancellable = true)
    private void cuffsx_onJump(CallbackInfo ci) {
        class_3222 self = (class_3222) (Object) this;
        if (CuffManager.isCuffed(self, CuffType.LEGS)) {
            ci.cancel();
        }
    }

    @Inject(method = "interactBlock", at = @At("HEAD"), cancellable = true)
    private void cuffsx_onInteractBlock(CallbackInfoReturnable<class_1269> ci) {
        class_3222 self = (class_3222) (Object) this;
        if (CuffManager.isCuffed(self, CuffType.HANDS)) {
            ci.cancel();
        }
    }

    @Inject(method = "interactItem", at = @At("HEAD"), cancellable = true)
    private void cuffsx_onInteractItem(CallbackInfoReturnable<net.minecraft.class_1271<net.minecraft.class_1799>> ci) {
        class_3222 self = (class_3222) (Object) this;
        if (CuffManager.isCuffed(self, CuffType.HANDS)) {
            ci.cancel();
        }
    }

    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void cuffsx_onAttack(class_1297 target, CallbackInfo ci) {
        class_3222 self = (class_3222) (Object) this;
        if (CuffManager.isCuffed(self, CuffType.HANDS)) {
            ci.cancel();
        }
    }
}
