package org.gloyer057.cuffsx.cuff;

import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class CuffState extends class_18 {
    public static final String KEY = "cuffsx_state";

    private final Map<UUID, Set<CuffRecord>> records = new HashMap<>();

    public void addRecord(CuffRecord record) {
        records.computeIfAbsent(record.targetUUID(), k -> new HashSet<>())
               .add(record);
        method_80();
    }

    public boolean removeRecord(UUID targetUUID, CuffType type) {
        Set<CuffRecord> set = records.get(targetUUID);
        if (set == null) return false;
        boolean removed = set.removeIf(r -> r.cuffType() == type);
        if (set.isEmpty()) records.remove(targetUUID);
        if (removed) method_80();
        return removed;
    }

    public Set<CuffRecord> getRecords(UUID targetUUID) {
        return records.getOrDefault(targetUUID, Collections.emptySet());
    }

    public Collection<CuffRecord> getAllRecords() {
        List<CuffRecord> all = new ArrayList<>();
        for (Set<CuffRecord> set : records.values()) all.addAll(set);
        return all;
    }

    public boolean hasCuff(UUID targetUUID, CuffType type) {
        Set<CuffRecord> set = records.get(targetUUID);
        if (set == null) return false;
        return set.stream().anyMatch(r -> r.cuffType() == type);
    }

    @Override
    public class_2487 method_75(class_2487 nbt) {
        class_2499 list = new class_2499();
        for (CuffRecord record : getAllRecords()) {
            list.add(record.toNbt());
        }
        nbt.method_10566("records", list);
        return nbt;
    }

    public static CuffState fromNbt(class_2487 nbt) {
        CuffState state = new CuffState();
        class_2499 list = nbt.method_10554("records", 10); // 10 = NbtCompound type
        for (int i = 0; i < list.size(); i++) {
            CuffRecord record = CuffRecord.fromNbt(list.method_10602(i));
            state.records.computeIfAbsent(record.targetUUID(), k -> new HashSet<>())
                         .add(record);
        }
        return state;
    }

    public static CuffState getOrCreate(MinecraftServer server) {
        return server.method_30002()
                .method_17983()
                .method_17924(CuffState::fromNbt, CuffState::new, KEY);
    }
}
