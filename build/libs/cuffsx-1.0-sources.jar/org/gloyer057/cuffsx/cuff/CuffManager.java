package org.gloyer057.cuffsx.cuff;

import org.gloyer057.cuffsx.item.ModItems;

import java.util.UUID;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

public class CuffManager {

    private static boolean enabled = true;

    private static final UUID LEGS_SPEED_MODIFIER_UUID =
            UUID.fromString("a1b2c3d4-e5f6-7890-abcd-ef1234567890");
    private static final String LEGS_SPEED_MODIFIER_NAME = "cuffsx_legs_speed";

    public static boolean isEnabled() { return enabled; }
    public static void setEnabled(boolean v) { enabled = v; }

    /**
     * Надеть наручники. Возвращает false если не удалось.
     */
    public static boolean applyCuffs(class_3222 applier,
                                     class_3222 target,
                                     CuffType type) {
        if (applier == target) return false;

        if (!enabled) {
            applier.method_7353(
                    net.minecraft.class_2561.method_43470("Наручники нельзя одеть на игрока в данный момент."),
                    false
            );
            return false;
        }

        CuffState state = CuffState.getOrCreate(applier.method_5682());

        if (state.hasCuff(target.method_5667(), type)) {
            return false;
        }

        CuffRecord record = new CuffRecord(
                target.method_5667(),
                applier.method_5667(),
                type,
                System.currentTimeMillis(),
                target.method_19538(),
                applier.method_5477().getString(),
                target.method_5477().getString()
        );

        state.addRecord(record);
        applier.method_6047().method_7934(1);
        CuffLog.log(CuffLog.Action.APPLY, record);
        applyRestrictions(target, type);

        return true;
    }

    /**
     * Снять наручники. Возвращает снятый CuffType или null.
     */
    public static CuffType removeCuffs(class_3222 applier,
                                       class_3222 target) {
        if (applier == target) return null;

        if (isCuffed(applier)) return null;
        if (!isCuffed(target)) return null;

        CuffState state = CuffState.getOrCreate(applier.method_5682());

        // Priority: HANDS before LEGS
        final CuffType typeToRemove;
        if (state.hasCuff(target.method_5667(), CuffType.HANDS)) {
            typeToRemove = CuffType.HANDS;
        } else if (state.hasCuff(target.method_5667(), CuffType.LEGS)) {
            typeToRemove = CuffType.LEGS;
        } else {
            return null;
        }

        // Find the record before removing (for logging)
        CuffRecord removedRecord = state.getRecords(target.method_5667()).stream()
                .filter(r -> r.cuffType() == typeToRemove)
                .findFirst()
                .orElse(null);

        state.removeRecord(target.method_5667(), typeToRemove);

        // Give item back to applier
        class_1799 stack = new class_1799(
                typeToRemove == CuffType.HANDS ? ModItems.HANDCUFFS_HANDS : ModItems.HANDCUFFS_LEGS
        );
        boolean inserted = applier.method_31548().method_7394(stack);
        if (!inserted) {
            applier.method_7328(stack, false);
        }

        if (removedRecord != null) {
            CuffLog.log(CuffLog.Action.REMOVE, removedRecord);
        }

        removeRestrictions(target, typeToRemove);

        return typeToRemove;
    }

    public static boolean isCuffed(class_3222 player, CuffType type) {
        CuffState state = CuffState.getOrCreate(player.method_5682());
        return state.hasCuff(player.method_5667(), type);
    }

    public static boolean isCuffed(class_3222 player) {
        return isCuffed(player, CuffType.HANDS) || isCuffed(player, CuffType.LEGS);
    }

    /**
     * Применить серверные ограничения (вызывается при надевании и при join).
     */
    public static void applyRestrictions(class_3222 player, CuffType type) {
        if (type == CuffType.LEGS) {
            class_1324 attr = player.method_5996(
                    class_5134.field_23719);
            if (attr != null) {
                attr.method_6200(LEGS_SPEED_MODIFIER_UUID);
                attr.method_26837(new class_1322(
                        LEGS_SPEED_MODIFIER_UUID,
                        LEGS_SPEED_MODIFIER_NAME,
                        -attr.method_6201(),
                        class_1322.class_1323.field_6328
                ));
            }
        }
        // HANDS restrictions are enforced via Mixin/events checking CuffState
    }

    /**
     * Снять серверные ограничения.
     */
    public static void removeRestrictions(class_3222 player, CuffType type) {
        if (type == CuffType.LEGS) {
            class_1324 attr = player.method_5996(
                    class_5134.field_23719);
            if (attr != null) {
                attr.method_6200(LEGS_SPEED_MODIFIER_UUID);
            }
        }
    }
}
