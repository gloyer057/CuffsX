package org.gloyer057.cuffsx.cuff;

import java.util.UUID;
import net.minecraft.class_243;
import net.minecraft.class_2487;

public record CuffRecord(
        UUID targetUUID,
        UUID applierUUID,
        CuffType cuffType,
        long timestamp,
        class_243 lockedPos,
        String applierName,
        String targetName
) {
    public class_2487 toNbt() {
        class_2487 nbt = new class_2487();
        nbt.method_10582("targetUUID", targetUUID.toString());
        nbt.method_10582("applierUUID", applierUUID.toString());
        nbt.method_10582("cuffType", cuffType.toNbt());
        nbt.method_10544("timestamp", timestamp);
        nbt.method_10549("lockedX", lockedPos.field_1352);
        nbt.method_10549("lockedY", lockedPos.field_1351);
        nbt.method_10549("lockedZ", lockedPos.field_1350);
        nbt.method_10582("applierName", applierName);
        nbt.method_10582("targetName", targetName);
        return nbt;
    }

    public static CuffRecord fromNbt(class_2487 nbt) {
        return new CuffRecord(
                UUID.fromString(nbt.method_10558("targetUUID")),
                UUID.fromString(nbt.method_10558("applierUUID")),
                CuffType.fromNbt(nbt.method_10558("cuffType")),
                nbt.method_10537("timestamp"),
                new class_243(
                        nbt.method_10574("lockedX"),
                        nbt.method_10574("lockedY"),
                        nbt.method_10574("lockedZ")
                ),
                nbt.method_10558("applierName"),
                nbt.method_10558("targetName")
        );
    }
}
