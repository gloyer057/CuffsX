package org.gloyer057.cuffsx.item;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.gloyer057.cuffsx.cuff.CuffType;

public class ModItems {
    public static final HandcuffsItem HANDCUFFS_HANDS = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960("cuffsx", "handcuffs_hands"),
            new HandcuffsItem(CuffType.HANDS)
    );

    public static final HandcuffsItem HANDCUFFS_LEGS = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960("cuffsx", "handcuffs_legs"),
            new HandcuffsItem(CuffType.LEGS)
    );

    public static void register() {
        // no-op: triggers static initializers
    }
}
