package org.gloyer057.cuffsx.item;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModItemGroups {
    public static final net.minecraft.class_1761 CUFFSX_GROUP = class_2378.method_10230(
            class_7923.field_44687,
            new class_2960("cuffsx", "cuffsx"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471("itemGroup.cuffsx.cuffsx"))
                    .method_47320(() -> new class_1799(ModItems.HANDCUFFS_HANDS))
                    .method_47317((ctx, entries) -> {
                        entries.method_45421(ModItems.HANDCUFFS_HANDS);
                        entries.method_45421(ModItems.HANDCUFFS_LEGS);
                    })
                    .method_47324()
    );

    public static void register() {
        // no-op: triggers static initializers
    }
}
