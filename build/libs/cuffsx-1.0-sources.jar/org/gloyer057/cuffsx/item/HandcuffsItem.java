package org.gloyer057.cuffsx.item;

import net.minecraft.class_1792;
import org.gloyer057.cuffsx.cuff.CuffType;

public class HandcuffsItem extends class_1792 {
    private final CuffType cuffType;

    public HandcuffsItem(CuffType cuffType) {
        super(new class_1792.class_1793().method_7889(16));
        this.cuffType = cuffType;
    }

    public CuffType getCuffType() {
        return cuffType;
    }
}
