package org.gloyer057.cuffsx;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import org.gloyer057.cuffsx.command.CuffsxCommand;
import org.gloyer057.cuffsx.cuff.CuffManager;
import org.gloyer057.cuffsx.cuff.CuffState;
import org.gloyer057.cuffsx.cuff.CuffType;
import org.gloyer057.cuffsx.item.HandcuffsItem;
import org.gloyer057.cuffsx.item.ModItemGroups;
import org.gloyer057.cuffsx.item.ModItems;

public class Cuffsx implements ModInitializer {

    @Override
    public void onInitialize() {
        // 10.1 — register items and creative tab
        ModItems.register();
        ModItemGroups.register();

        // 10.2 — apply/remove cuffs via right-click on player
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.method_8608()) return class_1269.field_5811;
            if (!(player instanceof class_3222 applier)) return class_1269.field_5811;
            if (!(entity instanceof class_3222 target)) return class_1269.field_5811;
            if (applier == target) return class_1269.field_5811;

            class_1799 stack = applier.method_5998(hand);
            if (stack.method_7909() instanceof HandcuffsItem hi) {
                CuffManager.applyCuffs(applier, target, hi.getCuffType());
                return class_1269.field_5812;
            }

            if (!CuffManager.isCuffed(applier) && CuffManager.isCuffed(target)) {
                CuffManager.removeCuffs(applier, target);
                return class_1269.field_5812;
            }

            return class_1269.field_5811;
        });

        // 10.3 — block breaking and block interaction blocked for HANDS
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (world.method_8608()) return class_1269.field_5811;
            if (player instanceof class_3222 sp && CuffManager.isCuffed(sp, CuffType.HANDS)) {
                return class_1269.field_5814;
            }
            return class_1269.field_5811;
        });

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.method_8608()) return class_1269.field_5811;
            if (player instanceof class_3222 sp && CuffManager.isCuffed(sp, CuffType.HANDS)) {
                return class_1269.field_5814;
            }
            return class_1269.field_5811;
        });

        // 10.4 — item use blocked for HANDS
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.method_8608()) return class_1271.method_22430(player.method_5998(hand));
            if (player instanceof class_3222 sp && CuffManager.isCuffed(sp, CuffType.HANDS)) {
                return class_1271.method_22431(player.method_5998(hand));
            }
            return class_1271.method_22430(player.method_5998(hand));
        });

        // 10.5 — teleport LEGS-cuffed players back to locked position each tick
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            CuffState state = CuffState.getOrCreate(server);
            for (class_3222 player : server.method_3760().method_14571()) {
                state.getRecords(player.method_5667()).stream()
                    .filter(r -> r.cuffType() == CuffType.LEGS)
                    .findFirst()
                    .ifPresent(r -> {
                        if (player.method_19538().method_1022(r.lockedPos()) > 0.1) {
                            player.method_20620(r.lockedPos().field_1352, r.lockedPos().field_1351, r.lockedPos().field_1350);
                        }
                    });
            }
        });

        // 10.6 — re-apply restrictions when a player joins or respawns
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.field_14140;
            CuffState state = CuffState.getOrCreate(server);
            state.getRecords(player.method_5667()).forEach(r ->
                CuffManager.applyRestrictions(player, r.cuffType()));
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            CuffState state = CuffState.getOrCreate(newPlayer.method_5682());
            state.getRecords(newPlayer.method_5667()).forEach(r ->
                CuffManager.applyRestrictions(newPlayer, r.cuffType()));
        });

        // 10.7 — register /cuffsx commands
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            CuffsxCommand.register(dispatcher));
    }
}
