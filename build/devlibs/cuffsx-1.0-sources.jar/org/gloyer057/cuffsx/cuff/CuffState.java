package org.gloyer057.cuffsx.cuff;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.util.*;

public class CuffState extends PersistentState {
    public static final String KEY = "cuffsx_state";

    private final Map<UUID, Set<CuffRecord>> records = new HashMap<>();

    public void addRecord(CuffRecord record) {
        records.computeIfAbsent(record.targetUUID(), k -> new HashSet<>())
               .add(record);
        markDirty();
    }

    public boolean removeRecord(UUID targetUUID, CuffType type) {
        Set<CuffRecord> set = records.get(targetUUID);
        if (set == null) return false;
        boolean removed = set.removeIf(r -> r.cuffType() == type);
        if (set.isEmpty()) records.remove(targetUUID);
        if (removed) markDirty();
        return removed;
    }

    public Set<CuffRecord> getRecords(UUID targetUUID) {
        return records.getOrDefault(targetUUID, Collections.emptySet());
    }

    public Collection<CuffRecord> getAllRecords() {
        List<CuffRecord> all = new ArrayList<>();
        for (Set<CuffRecord> set : records.values()) all.addAll(set);
        return all;
    }

    public boolean hasCuff(UUID targetUUID, CuffType type) {
        Set<CuffRecord> set = records.get(targetUUID);
        if (set == null) return false;
        return set.stream().anyMatch(r -> r.cuffType() == type);
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtList list = new NbtList();
        for (CuffRecord record : getAllRecords()) {
            list.add(record.toNbt());
        }
        nbt.put("records", list);
        return nbt;
    }

    public static CuffState fromNbt(NbtCompound nbt) {
        CuffState state = new CuffState();
        NbtList list = nbt.getList("records", 10); // 10 = NbtCompound type
        for (int i = 0; i < list.size(); i++) {
            CuffRecord record = CuffRecord.fromNbt(list.getCompound(i));
            state.records.computeIfAbsent(record.targetUUID(), k -> new HashSet<>())
                         .add(record);
        }
        return state;
    }

    public static CuffState getOrCreate(MinecraftServer server) {
        return server.getOverworld()
                .getPersistentStateManager()
                .getOrCreate(CuffState::fromNbt, CuffState::new, KEY);
    }
}
